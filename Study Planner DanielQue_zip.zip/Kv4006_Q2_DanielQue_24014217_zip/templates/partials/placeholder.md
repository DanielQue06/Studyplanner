This is a placeholder file to ensure the directory isn't empty. Once you have other things in here, you can delete it.

(I came across an odd bug, where an empty directory was getting stripped out. This file is just a workaround for that.)
