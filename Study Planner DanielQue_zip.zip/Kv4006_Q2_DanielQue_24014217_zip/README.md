# Daniel Que Read me files 

Hi before you enter the website please note that the 
email=Daniel@gmail.com
password=123
Your username Will be Daniel this has already been entered for you 
upon entry please note that some of the designs will not work due to the website not being fully funcational 
This website was a design plan to mimic a future app that will be used for future cyberattacks!
Not a full working website
However there are some features on here that you can see like the navagation bar at the top
I used jinja to template most of the pages.
Note that most things inside of more setting will be a darker black this means that it is 
pressable meaning that you can access the webpages linked so you can check that out.
However the features on the complete quiz do not work as this is not a fully functioning 
study planner app.
I have also included a footer on everypage stating copyright issues.
Please note pressing Daniel on the nav bar will take you out making it so you hace to log in agian
